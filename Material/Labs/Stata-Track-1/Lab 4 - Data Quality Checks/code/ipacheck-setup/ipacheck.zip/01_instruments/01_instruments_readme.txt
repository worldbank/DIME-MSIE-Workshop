++++++++++++++++
INSTRUMENTS
++++++++++++++++

This folder is designed to store a project's survey instruments. You should add a copy of the paper questionnaire as well as the latest version of the survey form (if you are using SurveyCTO, this should be the XLS form(s) in which you have programmed the survey and uploaded to the server). If your survey involves multiple forms, be sure they have names which clearly distinguish them. For example, "[PROJECT_NAME]_BASELINE_HOUSEHOLD" and "[PROJECT_NAME]_BASELINE_ADULT".
