++++++++++++++++
FIELD MANAGER
++++++++++++++++

This folder is designed to store any materials used principally by the field manager. This might include team rosters, with information such as name and contaction information for each enumerator, timelines/goals, and other strategic documents to ensure that data collection occurs smoothly.