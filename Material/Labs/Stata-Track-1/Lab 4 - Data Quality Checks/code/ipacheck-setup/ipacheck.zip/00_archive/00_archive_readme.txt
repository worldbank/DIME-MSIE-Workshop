++++++++++++++++
 ARCHIVE FOLDER
++++++++++++++++

This folder is designed to store old versions of files and facilitate version control.
We recommend that you name each file stored here with a date in order to better track old versions. For example, "[NAME_OF_FILE]_08072018".

Add aditional sub-folders in order to organize files. You might also want to create an individual "archive" folder inside each sub-folder to facilitate sub-categorization.


