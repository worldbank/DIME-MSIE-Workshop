++++++++++++++++
MEDIA
++++++++++++++++

This folder is designed to store any media files. If your survey captures any audio or video, you should specify the download location for the files containing those recordings to be here. This data is automatically considered personally identifiable information, so you need to make sure this folder is encrypted.